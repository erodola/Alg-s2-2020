"""
EXERCISE 2: Given a number x and a sequence A, find the closest number to x in the sequence.
"""

import math

x = 12.1
A = [3, 31, 7, 11, 52]

closest_val = -1
closest_dist = math.inf

for i in range(len(A)):
    d = abs(x - A[i])
    if d < closest_dist:
        closest_val = A[i]
        closest_dist = d

print(closest_val)
