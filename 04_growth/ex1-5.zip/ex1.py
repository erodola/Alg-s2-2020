"""
EXERCISE 1: Reverse any given sequence of length n.
"""

seq_in = [3, 7, 9, 14]
length = len(seq_in)

seq_out = []

for i in range(length):
    seq_out.append(seq_in[length-1-i])

print(seq_out)
