"""
EXERCISE 5: Given a number v and a sequence A, find the index i such that A[i] = v.
            The search must be done by binary search.
            Assume that the sequence A is sorted.
            Return a special value if v is not in A.
"""


def binsearch(S, x, i, f):
    if i < f:
        q = int((i + f) / 2)
        if x < S[q]:
            return binsearch(S, x, i, q)
        elif x > S[q]:
            return binsearch(S, x, q + 1, f)
        elif x == S[q]:
            return q + 1
    else:
        return -1


A = [11, 21, 31, 41, 51, 61, 71, 91]
v = 71
index = binsearch(A, v, 0, len(A))
print(index)
