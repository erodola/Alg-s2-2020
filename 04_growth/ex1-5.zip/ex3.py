"""
EXERCISE 3: Given two sequences A and B, find B inside A, and return the index of the first occurrence.
"""

A = "CGATTGC"
B = "TTG"

key_pos = 0
found = False
i = 0

while (not found) and (i != len(A)):
    cur_A = A[i]
    cur_B = B[key_pos]
    if cur_B == cur_A:
        key_pos += 1
    elif key_pos > 0:
        i = max(0, i - key_pos)
        key_pos = 0
    if key_pos == len(B):
        found = True
    i += 1

if not found:
    print('could not find B in A')
else:
    print(i-len(B)+1)
