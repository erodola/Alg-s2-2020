"""
EXERCISE 4: Given a number v and a sequence A, find the index i such that A[i] = v.
            The search must be done by linear scanning.
            Return a special value if v is not in A.
"""

v = 11
A = [3, 31, 7, 11, 52]

found = False

for i in range(len(A)):
    if A[i] == v:
        found = True
        break

if found:
    print(i)
else:
    print('not found')

'''
Best case:    The element is at the beginning of the list.
              Theta(1)
Average case: The element is in the middle of the list.
              Theta(n)
Worst case:   The element is at the end of the list, or is not in the list.
              Theta(n)
'''
