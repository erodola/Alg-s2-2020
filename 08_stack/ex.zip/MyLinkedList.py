class Node:
    
    def __init__(self, value, next):
        self.value = value
        self.next = next


class MyLinkedList:
    
    def __init__(self):
        self.head = None
    
    def insert(self, v):
        if self.head is None:
            self.head = Node(v, None)
        else:
            self.head = Node(v, self.head)
        return self.head

    def delete(self):
        old_head = self.head
        self.head = self.head.next
        old_head.next = None
    
    def search(self, v):
        cur = self.head
        while cur is not None and cur.value != v:
            cur = cur.next
        return cur


L = MyLinkedList()
L.insert(10)
L.insert(20)
x = L.insert(21)
L.delete()
