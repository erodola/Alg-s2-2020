class MyDeque:
    
    def __init__(self):
        self.list = MyDoublyLinkedlist()

    def enqueue_front(self, value):
        return self.list.insert_head(value)

    def enqueue_tail(self, value):  # Classical queue
        return self.list.insert_tail(value)

    def dequeue_front(self):  # Classical queue
        return self.list.delete_head()

    def dequeue_tail(self):
        return self.list.delete_tail()

