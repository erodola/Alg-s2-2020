class MyStack:

    # Constructor
    def __init__(self, max_size):
        self.data = [None]*max_size  # data field
        self.top = 0                 # pointer to the top (also a field)
        self.max_size = max_size     # maximum size of the stack (also a field)
    
    def is_empty(self):
        return self.top == 0

    # Define the push() method
    def push(self, v):
        if self.top == self.max_size:
            raise OverflowError
        self.data[self.top] = v
        self.top += 1
    
    def pop(self):
        if self.is_empty():
            raise OverflowError
        self.top -= 1
        return self.data[self.top]

    def print(self):
        print('-')
        for i in range(self.top):
            print(self.data[i])
        print('-')


s = MyStack(5)  # s is an object of type MyStack
s.push(1)
s.push(2)
s.push(17)
print(s.pop())
print(s.pop())
print(s.pop())
