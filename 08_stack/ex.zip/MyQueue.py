class MyQueue:
    
    def __init__(self, max_size):
        self.max_size = max_size
        self.head = 0
        self.tail = 0
        self.data = [None] * self.max_size
    
    def enqueue(self, v):
        self.data[self.tail] = v
        if self.tail == len(self.data)-1:
            self.tail = 0
        else:
            self.tail += 1
    
    def dequeue(self):
        pop = self.data[self.head]
        self.data[self.head] = None
        if self.head == len(self.data)-1:
            self.head = 0
        else:
            self.head += 1
        return pop


q = MyQueue(5)
q.enqueue(1)
q.enqueue(2)
q.enqueue(3)
x = q.dequeue()
x = q.dequeue()
q.enqueue(4)
q.enqueue(5)
q.enqueue(6)
