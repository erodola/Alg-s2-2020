class MyTreeNode:

    def __init__(self, value, left=None, right=None, parent=None):
        self.value = value
        self.left = left
        self.right = right
        self.parent = parent

    def print(self):
        print(self.value)


class MyBinaryTree:

    def __init__(self):
        self.root = None
        self.size = 0  # total number of nodes
    
    def _put(self, val, node):
        if val < node.value:
            if node.left is not None:
                self._put(val, node.left)
            else:
                node.left = MyTreeNode(val, None, None, node)
                return node.left
        if val > node.value:
            if node.right is not None:
                self._put(val, node.right)
            else:
                node.right = MyTreeNode(val, None, None, node)
                return node.right

    def append(self, value):
        if self.root is None:
            self.root = MyTreeNode(value)
        else:
            self._put(value, self.root)
        self.size += 1

    def print(self, node):
        node.print()
        if node.left is not None:
            self.print(node.left)
        if node.right is not None:
            self.print(node.right)


tree = MyBinaryTree()
tree.append(10)
tree.append(5)
tree.append(7)
